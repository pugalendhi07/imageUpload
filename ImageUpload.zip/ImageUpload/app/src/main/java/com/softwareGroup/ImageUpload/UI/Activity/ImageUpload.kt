package com.softwareGroup.ImageUpload.UI.Activity

import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.net.toUri
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.softwareGroup.ImageUpload.R
import com.softwareGroup.ImageUpload.ViewModel.ImageUploadViewModel
import com.softwareGroup.ImageUpload.ResponseInterface.ImageUploadResponseInterface
import com.softwareGroup.ImageUpload.JsonResponse.ErrorBody
import com.softwareGroup.ImageUpload.JsonResponse.UploadResponse
import java.io.ByteArrayOutputStream
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class ImageUpload : AppCompatActivity(), ImageUploadResponseInterface {
    private var selectedImage: Bitmap? = null
    private var currentPhotoPath: String? = null
    lateinit var choose: Button
    lateinit var upload: Button
    lateinit var imagePreview: ImageView
    lateinit var cross: ImageView
    lateinit var progress: ProgressBar
    lateinit var fileInfoTextView: TextView
    private var capturedImageUri: Uri? = null
    var imageUploadViewModel: ImageUploadViewModel? = null
    var imageBase64:String = "";

    companion object {
        private const val PICK_IMAGE_REQUEST = 1
        private const val CAMERA_PERMISSION_REQUEST_CODE = 100
        private const val CAMERA_IMAGE_REQUEST = 1001
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_image_upload)
        choose = findViewById(R.id.choose)
        upload = findViewById(R.id.upload)
        progress = findViewById(R.id.progress)
        imagePreview = findViewById(R.id.imagePreview)
        cross = findViewById(R.id.cross)
        fileInfoTextView = findViewById(R.id.fileInfoTextView)
        imageUploadViewModel = ImageUploadViewModel()

        choose.setOnClickListener {
            bottomSheet()
        }

        cross.setOnClickListener {

            cross.visibility = View.GONE
            upload.visibility = View.GONE
            choose.visibility = View.VISIBLE

            imagePreview.setImageResource(0);

        }
        upload.setOnClickListener {
            submitImage()
        }


        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!checkCameraPermission()) {
                requestCameraPermission()
            }
        }

    }

    private fun bottomSheet() {
        val bottomSheetDialog = BottomSheetDialog(this, R.style.AppBottomSheetDialogTheme)
        bottomSheetDialog.setContentView(R.layout.bottom_dialog)
        var camera: CardView? = bottomSheetDialog.findViewById(R.id.camera)
        var gallery: CardView? = bottomSheetDialog.findViewById(R.id.gallery)

        gallery!!.setOnClickListener {
            openImageChooser()
            bottomSheetDialog.dismiss()
        }

        camera!!.setOnClickListener {
            if (!checkCameraPermission()) {
                requestCameraPermission()
                return@setOnClickListener
            }
            dispatchTakePictureIntent()
            bottomSheetDialog.dismiss()
        }

        bottomSheetDialog.show()
    }

    private fun openImageChooser() {
        val intent = Intent(Intent.ACTION_GET_CONTENT)
        intent.type = "image/*"
        startActivityForResult(intent, PICK_IMAGE_REQUEST)
    }

    private fun dispatchTakePictureIntent() {
        val timeStamp: String =
            SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())

        val capturedImageFile = File(
            getExternalFilesDir(Environment.DIRECTORY_PICTURES),
            timeStamp + "captured_image.jpg"
        )

        capturedImageUri = FileProvider.getUriForFile(
            this,
            "com.softwareGroup.ImageUpload.provider",
            capturedImageFile
        )

        val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, capturedImageUri)
        startActivityForResult(cameraIntent, CAMERA_IMAGE_REQUEST)

    }


    private fun displaySelectedImage() {
        if (selectedImage != null) {
            imagePreview.setImageBitmap(selectedImage)

        } else if (currentPhotoPath != null) {
            imagePreview.setImageURI(currentPhotoPath?.toUri())
        }
        try {
            imageBase64 =  bitmapToBase64(selectedImage!!)
        }catch (e:Exception){
            e.printStackTrace()
        }

        cross.visibility = View.VISIBLE
        upload.visibility = View.VISIBLE
        choose.visibility = View.GONE
    }

    private fun checkCameraPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            this,
            android.Manifest.permission.CAMERA
        ) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestCameraPermission() {
        ActivityCompat.requestPermissions(
            this,
            arrayOf(
                android.Manifest.permission.CAMERA,
                android.Manifest.permission.WRITE_EXTERNAL_STORAGE
            ),
            CAMERA_PERMISSION_REQUEST_CODE
        )
    }

    private fun submitImage() {

        upload.text = ""
        progress.visibility = View.VISIBLE
        upload.isEnabled = false
        imageUploadViewModel!!.LogincallEnqueue(imageBase64, this)


    }

    fun bitmapToBase64(bitmap: Bitmap): String {
        val byteArrayOutputStream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream)
        val byteArray = byteArrayOutputStream.toByteArray()
        return Base64.encodeToString(byteArray, Base64.DEFAULT)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null) {
            val selectedImageUri = data.data
            selectedImage = MediaStore.Images.Media.getBitmap(contentResolver, selectedImageUri)
            selectedImage = compressImage(selectedImage!!)
            displaySelectedImage()
        } else if (requestCode == CAMERA_IMAGE_REQUEST && resultCode == RESULT_OK) {
            if (capturedImageUri != null) {
                selectedImage = MediaStore.Images.Media.getBitmap(contentResolver, capturedImageUri)
                selectedImage = compressImage(selectedImage!!)
                displaySelectedImage()
            }
        }
    }


    private fun compressImage(imageBitmap: Bitmap): Bitmap {
        val contentValues = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "compressed_image.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
        }

        val compressedImageUri =
            contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)

        compressedImageUri?.let { uri ->
            val outputStream = contentResolver.openOutputStream(uri)
            imageBitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream)
            outputStream?.close()
        }

        val compressedImageBitmap =
            BitmapFactory.decodeStream(contentResolver.openInputStream(compressedImageUri!!))
        return compressedImageBitmap
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String?>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == CAMERA_PERMISSION_REQUEST_CODE) {
        }
    }

    override fun imageUploadResponse(response: UploadResponse?) {
        progress.visibility = View.GONE
        if (response != null) {
            Toast.makeText(this,""+response.message,Toast.LENGTH_LONG).show()
        }
        upload.visibility = View.GONE
        upload.text = "Upload"
        upload.isEnabled = true

    }

    override fun onFailure(errorBody: ErrorBody?, statusCode: Int) {
        progress.visibility = View.GONE
        upload.text = "Upload"
        upload.isEnabled = true

    }

}
