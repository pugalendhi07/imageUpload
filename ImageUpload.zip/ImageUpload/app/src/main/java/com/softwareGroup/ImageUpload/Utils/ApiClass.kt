package com.softwareGroup.ImageUpload.Utils

object ApiClass {

    const val BASE_URL = "https://upload.imagekit.io/api/v1/"

    /*Image Upload*/
    const val UPLOAD = "files/upload"

}