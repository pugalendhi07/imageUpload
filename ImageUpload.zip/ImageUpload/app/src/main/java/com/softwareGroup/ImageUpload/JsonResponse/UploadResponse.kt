package com.softwareGroup.ImageUpload.JsonResponse;
import com.fasterxml.jackson.annotation.JsonProperty

data class UploadResponse(


    @JsonProperty("message")
    var message: String? = null,
    @JsonProperty("error")
    var error: Boolean? = null,
    @JsonProperty("help")
    var help: String? = null,
   

)

