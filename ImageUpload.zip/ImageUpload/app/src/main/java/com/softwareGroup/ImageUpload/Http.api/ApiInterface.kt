package com.mdq.social.app.data.api


import com.softwareGroup.ImageUpload.JsonResponse.UploadResponse
import com.softwareGroup.ImageUpload.Utils.ApiClass
import retrofit2.Call
import retrofit2.http.*

interface ApiInterface {

    @FormUrlEncoded
    @POST(ApiClass.UPLOAD)
    fun upload(
        @Field("file") file: String
    ): Call<UploadResponse?>?

  }