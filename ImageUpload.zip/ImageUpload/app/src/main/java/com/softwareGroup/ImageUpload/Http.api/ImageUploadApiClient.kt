package com.mdq.social.app.data.api
import com.softwareGroup.ImageUpload.Utils.ApiClass
import java.util.concurrent.TimeUnit
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.jackson.JacksonConverterFactory


//For making the connection with the backend server
object ImageUploadApiClient {
    private var retrofit: Retrofit? = null

    fun apiinterface(): ApiInterface {

        if (retrofit == null) {
            val defaultHttpClient: OkHttpClient = OkHttpClient.Builder()
                .addInterceptor(HttpLoggingInterceptor().setLevel(HttpLoggingInterceptor.Level.BODY))
                .connectTimeout(10, TimeUnit.MINUTES)
                .retryOnConnectionFailure(true)
                .build()
            retrofit = Retrofit.Builder()
                .baseUrl(ApiClass!!.BASE_URL)
                .addConverterFactory(JacksonConverterFactory.create())
                .client(defaultHttpClient)
                .build()
        }
        return retrofit!!.create(ApiInterface::class.java)
    }
}


