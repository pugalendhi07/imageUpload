package com.softwareGroup.ImageUpload.ResponseInterface
import com.softwareGroup.ImageUpload.JsonResponse.ErrorBody
import com.softwareGroup.ImageUpload.JsonResponse.UploadResponse


interface ImageUploadResponseInterface  {
    fun imageUploadResponse(response: UploadResponse?)
    fun onFailure(errorBody: ErrorBody?, statusCode: Int)
}